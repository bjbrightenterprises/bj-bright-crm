import React, { useState } from 'react';
import { CRMProvider, useCRM } from './context/CRMContext';
import { Sidebar, NavItem } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardModule } from './components/dashboard/DashboardModule';
import { CandidatesModule } from './components/candidates/CandidatesModule';
import { ClientsModule } from './components/clients/ClientsModule';
import { JobsModule } from './components/jobs/JobsModule';
import { PipelineKanbanModule } from './components/pipeline/PipelineKanbanModule';
import { InterviewsModule } from './components/interviews/InterviewsModule';
import { SettingsModule } from './components/settings/SettingsModule';
import { ReportsAnalyticsModule } from './components/reports/ReportsAnalyticsModule';
import { MyTasksModule } from './components/reminders/MyTasksModule';
import { LoginScreen } from './components/auth/LoginScreen';
import { AccessRestricted } from './components/common/AccessRestricted';

import { CandidateFormModal } from './components/candidates/CandidateFormModal';
import { JobFormModal } from './components/jobs/JobFormModal';
import { ClientFormModal } from './components/clients/ClientFormModal';
import { ScheduleInterviewModal } from './components/interviews/ScheduleInterviewModal';
import { CandidateProfileModal } from './components/candidates/CandidateProfileModal';
import { Candidate, Client } from './types/crm';

const CRMAppContent: React.FC = () => {
  const {
    currentUser,
    firebaseAuthActive,
    authReady,
    isAuthenticated,
    syncReady,
    syncError,
    dismissSyncError,
    logout,
  } = useCRM();
  const [isLocalLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('bj_logged_in') === 'true';
  });
  const isLoggedIn = firebaseAuthActive ? isAuthenticated : isLocalLoggedIn;

  const [currentTab, setCurrentTab] = useState<NavItem>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Global modals
  const [isAddCandidateOpen, setIsAddCandidateOpen] = useState(false);
  const [isAddJobOpen, setIsAddJobOpen] = useState(false);
  const [isAddClientOpen, setIsAddClientOpen] = useState(false);
  const [isScheduleInterviewOpen, setIsScheduleInterviewOpen] = useState(false);

  // Profile modal & preselected entities
  const [activeCandidateForProfile, setActiveCandidateForProfile] = useState<Candidate | null>(null);
  const [candidateToEdit, setCandidateToEdit] = useState<Candidate | null>(null);

  const [preSelectedJobIdForPipeline, setPreSelectedJobIdForPipeline] = useState<string | undefined>();
  const [preSelectedClientIdForJob, setPreSelectedClientIdForJob] = useState<string | undefined>();
  const [preSelectedCandidateForInterview, setPreSelectedCandidateForInterview] = useState<Candidate | null>(null);

  if (firebaseAuthActive && !authReady) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-300 text-sm">
        Loading...
      </div>
    );
  }

  if (!isLoggedIn) {
    return <LoginScreen onLoginSuccess={() => setIsLoggedIn(true)} />;
  }

  if (firebaseAuthActive && !syncReady) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-4 p-6 text-center text-slate-300 text-sm">
        {syncError ? (
          <>
            <p className="max-w-md text-rose-400 font-semibold">Could not load data from Firebase.</p>
            <p className="max-w-md text-xs text-slate-400 break-words">{syncError}</p>
            <button
              onClick={() => logout()}
              className="px-4 py-2 rounded-lg bg-[#F5A623] text-slate-950 font-bold text-xs"
            >
              Log out
            </button>
          </>
        ) : (
          <p>Syncing your CRM data...</p>
        )}
      </div>
    );
  }

  const handleNavigate = (tab: NavItem) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToPipeline = (jobId?: string) => {
    setPreSelectedJobIdForPipeline(jobId);
    setCurrentTab('pipeline');
  };

  const handleOpenCreateJobForClient = (client: Client) => {
    setPreSelectedClientIdForJob(client.id);
    setIsAddJobOpen(true);
  };

  const handleScheduleInterviewForCandidate = (candidate: Candidate) => {
    setPreSelectedCandidateForInterview(candidate);
    setIsScheduleInterviewOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={handleNavigate}
        isOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="lg:pl-68 flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <Header
          onOpenMobileSidebar={() => setIsMobileSidebarOpen(true)}
          onNavigate={handleNavigate}
          onOpenAddCandidate={() => setIsAddCandidateOpen(true)}
          onOpenAddJob={() => {
            setPreSelectedClientIdForJob(undefined);
            setIsAddJobOpen(true);
          }}
          onOpenAddClient={() => setIsAddClientOpen(true)}
          onOpenScheduleInterview={() => {
            setPreSelectedCandidateForInterview(null);
            setIsScheduleInterviewOpen(true);
          }}
          onOpenFirebaseModal={() => {}}
          onLogout={() => {
            if (firebaseAuthActive) {
              logout();
              return;
            }
            localStorage.removeItem('bj_logged_in');
            setIsLoggedIn(false);
          }}
        />

        {/* Dynamic Page Views */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentTab === 'dashboard' && (
            <DashboardModule
              onNavigate={handleNavigate}
              onOpenCandidateForm={() => setIsAddCandidateOpen(true)}
              onOpenScheduleInterview={() => setIsScheduleInterviewOpen(true)}
            />
          )}

          {currentTab === 'candidates' && (
            <CandidatesModule
              onScheduleInterviewForCandidate={handleScheduleInterviewForCandidate}
            />
          )}

          {currentTab === 'clients' && (
            <ClientsModule onOpenCreateJobForClient={handleOpenCreateJobForClient} />
          )}

          {currentTab === 'jobs' && (
            <JobsModule
              onNavigateToPipeline={handleNavigateToPipeline}
              onViewCandidateProfile={(cand) => setActiveCandidateForProfile(cand)}
            />
          )}

          {currentTab === 'pipeline' && (
            <PipelineKanbanModule
              initialJobId={preSelectedJobIdForPipeline}
              onViewCandidateProfile={(cand) => setActiveCandidateForProfile(cand)}
              onScheduleInterview={handleScheduleInterviewForCandidate}
            />
          )}

          {currentTab === 'interviews' && (
            <InterviewsModule
              onViewCandidateProfile={(cand) => setActiveCandidateForProfile(cand)}
            />
          )}

          {currentTab === 'tasks' && (
            <MyTasksModule
              onViewCandidateProfile={(cand) => setActiveCandidateForProfile(cand)}
            />
          )}

          {currentTab === 'reports' && <ReportsAnalyticsModule />}

          {currentTab === 'settings' && (
            currentUser.role === 'admin' ? (
              <SettingsModule />
            ) : (
              <AccessRestricted onNavigate={handleNavigate} />
            )
          )}
        </main>
      </div>

      {syncError && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[100] max-w-lg w-[92%] bg-rose-600 text-white text-xs rounded-xl shadow-2xl px-4 py-3 flex items-start gap-3">
          <span className="flex-1 break-words">{syncError}</span>
          <button onClick={dismissSyncError} className="font-bold shrink-0" aria-label="Dismiss">
            ✕
          </button>
        </div>
      )}

      {/* Global Modals */}
      <CandidateFormModal
        isOpen={isAddCandidateOpen}
        onClose={() => {
          setIsAddCandidateOpen(false);
          setCandidateToEdit(null);
        }}
        candidateToEdit={candidateToEdit}
      />

      <JobFormModal
        isOpen={isAddJobOpen}
        onClose={() => {
          setIsAddJobOpen(false);
          setPreSelectedClientIdForJob(undefined);
        }}
        preSelectedClientId={preSelectedClientIdForJob}
      />

      <ClientFormModal
        isOpen={isAddClientOpen}
        onClose={() => setIsAddClientOpen(false)}
      />

      <ScheduleInterviewModal
        isOpen={isScheduleInterviewOpen}
        onClose={() => {
          setIsScheduleInterviewOpen(false);
          setPreSelectedCandidateForInterview(null);
        }}
        preSelectedCandidate={preSelectedCandidateForInterview}
      />

      {/* Candidate Profile Modal */}
      <CandidateProfileModal
        isOpen={!!activeCandidateForProfile}
        onClose={() => setActiveCandidateForProfile(null)}
        candidate={activeCandidateForProfile}
        onEdit={(cand) => {
          setActiveCandidateForProfile(null);
          setCandidateToEdit(cand);
          setIsAddCandidateOpen(true);
        }}
        onScheduleInterview={(cand) => {
          setActiveCandidateForProfile(null);
          handleScheduleInterviewForCandidate(cand);
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <CRMProvider>
      <CRMAppContent />
    </CRMProvider>
  );
}
